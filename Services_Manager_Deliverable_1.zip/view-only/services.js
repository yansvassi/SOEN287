
function myFunction() {
  alert("Log in to acess the page");
}
